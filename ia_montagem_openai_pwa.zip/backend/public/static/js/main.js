// static/js/main.js
import React, { useState } from 'https://cdn.skypack.dev/react';
import { createRoot } from 'https://cdn.skypack.dev/react-dom/client';

function App() {
  const [imageA, setImageA] = useState(null);
  const [imageB, setImageB] = useState(null);
  const [previewA, setPreviewA] = useState(null);
  const [previewB, setPreviewB] = useState(null);
  const [status, setStatus] = useState('');
  const [resultUrl, setResultUrl] = useState(null);

  function handleFileA(e) {
    const f = e.target.files[0];
    setImageA(f);
    setPreviewA(URL.createObjectURL(f));
  }
  function handleFileB(e) {
    const f = e.target.files[0];
    setImageB(f);
    setPreviewB(URL.createObjectURL(f));
  }

  async function sendCompose() {
    if (!imageA || !imageB) return alert('Envie as duas imagens primeiro.');
    setStatus('Enviando imagens...');
    const form = new FormData();
    form.append('imageA', imageA);
    form.append('imageB', imageB);
    form.append('prompt', 'Blend the subject onto the background with natural lighting and soft shadows');

    try {
      setStatus('Processando (OpenAI)...');
      const res = await fetch('/api/compose', { method: 'POST', body: form });
      if (!res.ok) throw new Error(await res.text());
      const json = await res.json();
      setResultUrl(json.result_url);
      setStatus('Pronto! Veja o resultado abaixo.');
    } catch (err) {
      console.error(err);
      setStatus('Erro: ' + (err.message || err));
    }
  }

  return (
    React.createElement('div', { style: { fontFamily: 'sans-serif', padding: 20, maxWidth: 800, margin: 'auto' } },
      React.createElement('h1', null, 'IA de Montagem — PWA (Protótipo)'),
      React.createElement('p', null, 'Envie sujeito (A) e fundo (B). O servidor usa a OpenAI Images Edit para compor.'),
      React.createElement('div', { style: { display: 'flex', gap: 20 } },
        React.createElement('div', null,
          React.createElement('div', null, React.createElement('label', null, 'Sujeito (A)'), React.createElement('input', { type: 'file', accept: 'image/*', onChange: handleFileA })),
          previewA && React.createElement('img', { src: previewA, style: { maxHeight: 160, display: 'block', marginTop: 8 } })
        ),
        React.createElement('div', null,
          React.createElement('div', null, React.createElement('label', null, 'Fundo (B)'), React.createElement('input', { type: 'file', accept: 'image/*', onChange: handleFileB })),
          previewB && React.createElement('img', { src: previewB, style: { maxHeight: 160, display: 'block', marginTop: 8 } })
        )
      ),
      React.createElement('div', { style: { marginTop: 12 } },
        React.createElement('button', { onClick: sendCompose, style: { padding: '8px 12px', marginRight: 8 } }, 'Gerar Montagem'),
        React.createElement('button', { onClick: () => { setImageA(null); setImageB(null); setPreviewA(null); setPreviewB(null); setResultUrl(null); setStatus(''); } }, 'Reset')
      ),
      React.createElement('p', { style: { color: '#444' } }, 'Status: ' + status),
      resultUrl && React.createElement('div', { style: { marginTop: 16 } },
        React.createElement('h3', null, 'Resultado'),
        React.createElement('img', { src: resultUrl, style: { maxWidth: '100%' } }),
        React.createElement('p', { style: { fontSize: 12, color: '#666' } }, 'Clique com o botão direito e salve a imagem.')
      )
    )
  );
}

const container = document.getElementById('root');
const root = createRoot(container);
root.render(React.createElement(App));
