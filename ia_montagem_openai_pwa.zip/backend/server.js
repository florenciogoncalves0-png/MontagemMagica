// backend/server.js
// Node/Express server that receives two images (subject and background), calls OpenAI Images Edit
// Requires environment variable: OPENAI_API_KEY
const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch'); // npm install node-fetch@2
const FormData = require('form-data'); // npm install form-data

const upload = multer({ dest: 'tmp/' });
const app = express();
app.use(express.json());

// Helper: call OpenAI Images Edit API
async function callOpenAIImageEdit(backgroundPath, maskPath, prompt) {
  const url = 'https://api.openai.com/v1/images/edits';
  const form = new FormData();
  form.append('model', 'gpt-image-1');
  form.append('image', fs.createReadStream(backgroundPath)); // base image
  if (maskPath && fs.existsSync(maskPath)) {
    form.append('mask', fs.createReadStream(maskPath));
  }
  form.append('prompt', prompt || 'Blend the subject onto the background with natural lighting and soft shadows');

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer ' + process.env.OPENAI_API_KEY
    },
    body: form
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error('OpenAI API error: ' + res.status + ' - ' + text);
  }
  const data = await res.json();
  // The API returns base64 data in data.data[0].b64_json for some SDKs, or a url.
  // We'll support both possibilities.
  if (data.data && data.data[0] && data.data[0].b64_json) {
    const b64 = data.data[0].b64_json;
    const buf = Buffer.from(b64, 'base64');
    const outPath = path.join('public', 'results', 'openai_edit_' + Date.now() + '.png');
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    fs.writeFileSync(outPath, buf);
    return outPath;
  } else if (data.data && data.data[0] && data.data[0].url) {
    // If OpenAI returns a URL, download it
    const imageUrl = data.data[0].url;
    const fetchRes = await fetch(imageUrl);
    if (!fetchRes.ok) throw new Error('Failed to download image from OpenAI: ' + fetchRes.status);
    const outPath = path.join('public', 'results', 'openai_edit_' + Date.now() + '.png');
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    const fileStream = fs.createWriteStream(outPath);
    await new Promise((resolve, reject) => {
      fetchRes.body.pipe(fileStream);
      fetchRes.body.on("error", reject);
      fileStream.on("finish", resolve);
    });
    return outPath;
  } else {
    throw new Error('Unexpected OpenAI response format');
  }
}

// Simple segmentation stub: copies subject as mask (for production replace with SAM)
async function generateMaskStub(subjectPath) {
  const maskPath = subjectPath + '.mask.png';
  fs.copyFileSync(subjectPath, maskPath);
  return maskPath;
}

app.post('/api/compose', upload.fields([{ name: 'imageA' }, { name: 'imageB' }]), async (req, res) => {
  try {
    const fileA = req.files['imageA'][0]; // subject
    const fileB = req.files['imageB'][0]; // background

    // 1) Generate mask (stub). Replace with real SAM call if available.
    const maskPath = await generateMaskStub(fileA.path);

    // 2) Call OpenAI Images Edit to blend subject over background using mask and prompt
    const prompt = req.body.prompt || 'Blend the subject onto the background with natural lighting and soft shadows, match color and add realistic shadow';
    let resultPath;
    try {
      resultPath = await callOpenAIImageEdit(fileB.path, maskPath, prompt);
    } catch (openaiErr) {
      console.error('OpenAI failed, falling back to background copy:', openaiErr);
      // fallback: copy background as a result
      const fallback = path.join('public', 'results', 'fallback_' + Date.now() + '.png');
      fs.mkdirSync(path.dirname(fallback), { recursive: true });
      fs.copyFileSync(fileB.path, fallback);
      resultPath = fallback;
    }

    const publicUrl = '/results/' + path.basename(resultPath);
    res.json({ result_url: publicUrl });
  } catch (err) {
    console.error(err);
    res.status(500).send('Erro no servidor: ' + err.message);
  }
});

// Serve static files (frontend build + results)
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('Server rodando na porta', PORT));
