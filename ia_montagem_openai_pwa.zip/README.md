IA de Montagem - OpenAI + PWA (Protótipo)

O que tem neste pacote:
  - backend/server.js    -> Node/Express que chama a OpenAI Images Edit API
  - backend/public/*     -> frontend PWA (index.html, manifest, service-worker, static/js/main.js)
  - Dockerfile           -> imagem pronta para subir (multi-stage simples)
  - render.yaml          -> configuração para deploy no Render

Passos para rodar localmente:

1) Preparar backend:
   cd backend
   npm init -y
   npm install express multer node-fetch@2 form-data
   # Defina sua chave da OpenAI:
   export OPENAI_API_KEY=your_key_here
   node server.js
   # O servidor ficará disponível em http://localhost:3000

2) Abrir o navegador:
   Acesse http://localhost:3000 e envie duas imagens (sujeito e fundo).
   Observação: a geração de máscara é apenas um stub (copia a imagem). Para melhores resultados, integre SAM ou outro serviço de segmentação e substitua generateMaskStub().

3) Deploy com Docker (exemplo):
   docker build -t ia-montagem .
   docker run -p 3000:3000 -e OPENAI_API_KEY=your_key ia-montagem

4) Deploy no Render:
   - Crie conta no Render (render.com)
   - Crie um novo Web Service -> conectar repo ou enviar Dockerfile via Docker deploy
   - Defina variável de ambiente OPENAI_API_KEY no painel -> Deploy

Como transformar em APK / Play Store:
  - Este protótipo é uma PWA: no Android abra no Chrome e selecione 'Instalar app' (ou 'Adicionar à tela inicial').
  - Para publicar na Play Store como APK/AAB: converta este frontend para React Native ou encapsule a PWA em um WebView usando Android Studio e gere o .aab.
  - Você precisará de Conta de Desenvolvedor Google Play (US$25) para publicar.

Importante:
  - NÃO compartilhe sua OPENAI_API_KEY publicamente.
  - Para produção, implemente autenticação, limites de uso e moderação de conteúdo.
